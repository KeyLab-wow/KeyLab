KeyLab Gear Targets Rebuild - Static Loot Database Version

Changed architecture:
- Removed the live Adventure Guide scanner/marker load path.
- Gear Targets now reads from KeyLab's static Midnight Season 1 loot database.
- Player SavedVariables store only checked target itemIDs per character/spec.

Files added:
- database/KeyLab_GearLootDatabase.lua
- mapping/KeyLab_GearLootMapping.lua
- ui/KeyLab_GearTargets.lua

Files changed:
- KeyLab.toc
- KeyLab_UI.lua
- database/KeyLab_DB.lua
- database/KeyLab_LootTargetsDB.lua
- ui/KeyLab_GearTargetsWindow.lua
- ui/KeyLab_Home.lua

Files no longer needed / removed from TOC:
- capture/KeyLab_AdventureGuideLootScanner.lua
- ui/KeyLab_AdventureGuideTargets.lua

If you unzip this full addon over an existing folder, those two old files may still physically remain, but they are no longer loaded. For a perfectly clean install, delete the old KeyLab folder first, then unzip this full folder.

New Gear Targets behavior:
- Gear Targets tab is back in the sidebar.
- Filters: Loot Spec, Slot, Dungeon, Primary/Stamina, Secondary Stats, Checked Items Only.
- Checkboxes save immediately to the selected spec, or current spec when Loot Spec is All Specs.
- Gear Targets window can be opened from Home.
- LFG Premade Group dungeon browsing still auto-opens/updates the Gear Targets window.
- Non-gear items such as recipes, mounts, decor, and housing items are preserved in the database/list.
